from random import Random, randrange
import string
from tkinter import *

screen = Tk()

#pic = open('index_3KB_icon.ico', 'rb')

def Word_Engine():

    textran = ""

    textgenerated = False

    randomword = randrange(1, 11)

    if randomword == 1:
        textran = "Dude"
        textgenerated = True

    if randomword == 2:
        textran = " Tut "
        textgenerated = True

    if randomword == 3:
        textran = " Ayo "
        textgenerated = True

    if randomword == 4:
        textran = "  4k  "
        textgenerated = True

    if randomword == 5:
        textran = "_Mom "
        textgenerated = True

    if randomword == 6:
        textran = "Animal"
        textgenerated = True

    if randomword == 7:
        textran = "Wild"
        textgenerated = True

    if randomword == 8:
        textran = "Jordan"
        textgenerated = True


    if randomword == 9:
        textran = "Py"

    if randomword == 10:
        textran = "IO"

    text2 = Label(screen, text=input_field.get() + textran)
    text2.grid(row=1, columnspan=3)


text = Label(screen, text="Write to print:")
text.grid(row=0, column=0)

input_field = Entry(screen)
input_field.grid(row=0, column=1)

submit_button = Button(screen, text="Generate!", fg="yellow", bg="purple", command=Word_Engine)
submit_button.grid(row=0, column=2)


screen.title("Pygine - A word engine!")

#screen.iconbitmap("index_3KB_icon.ico")

screen.mainloop()
