word_file = "words.txt"
WORDS = open(word_file).read().splitlines()

print(WORDS)